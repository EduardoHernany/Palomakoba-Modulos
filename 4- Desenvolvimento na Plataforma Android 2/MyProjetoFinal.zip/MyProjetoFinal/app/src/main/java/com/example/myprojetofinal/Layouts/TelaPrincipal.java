package com.example.myprojetofinal.Layouts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.BatteryManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.myprojetofinal.R;

public class TelaPrincipal extends AppCompatActivity implements SensorEventListener {
    private Button buscarCep,lisraendereco;

    private SensorManager sensorManager;
    private Sensor sensor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_principal);

        iniciarcomponentes();
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        buscarCep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddDialogFragment dialogFragment = new AddDialogFragment();
                dialogFragment.setCancelable(false);

                dialogFragment.show(getSupportFragmentManager(),dialogFragment.getTag());
            }
        });

        lisraendereco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Lista.class);
                startActivity(intent);
            }
        });



    }

    private void iniciarcomponentes() {
        buscarCep= findViewById(R.id.buscarCep);

        lisraendereco = findViewById(R.id.btn_lista_endereco);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(TelaPrincipal.this, sensor, SensorManager.SENSOR_DELAY_NORMAL);
        this.registerReceiver(nivel_bateria, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(TelaPrincipal.this);
        this.unregisterReceiver(nivel_bateria);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {


        if (sensorEvent.values[0] > 16) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Toast.makeText(this, "Fechando o aplicativo", Toast.LENGTH_SHORT).show();
            try {
                Thread.sleep(700);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            finish();
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    public BroadcastReceiver nivel_bateria = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            int nivel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
            Log.i("val", "nivel: "+nivel);
            if (nivel < 50) {
                Toast.makeText(context, "O nível da bateria está abaixo de 50%", Toast.LENGTH_SHORT).show();

            }
        }
    };
}