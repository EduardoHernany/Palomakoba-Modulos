package com.example.myprojetofinal.adapter;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myprojetofinal.Layouts.MapsActivity2;
import com.example.myprojetofinal.R;
import com.example.myprojetofinal.bd.BancoControlador;

import java.util.ArrayList;
import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {
    private List<ContentValues> listEndereco = new ArrayList<>();

    public Adapter(List<ContentValues> listEndereco) {
        this.listEndereco = listEndereco;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemLista= LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_endereco, parent, false);

        return new MyViewHolder(itemLista);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        ContentValues cv = new ContentValues();
        cv = listEndereco.get(position);
        String cep =cv.getAsString("cep");
        String logradouro = cv.getAsString("logradouro");
        String complemento = cv.getAsString("complemento");
        String bairro = cv.getAsString("bairro");
        String uf = cv.getAsString("uf");
        String localidade = cv.getAsString("localidade");
        String id = cv.getAsString("id");

        holder.txt_um.setText(logradouro+ ", "+complemento+ " - "+ bairro);
        holder.txt_dois.setText(localidade+" - "+uf+" - "+cep);
        holder.txt_id.setText(id);

    }

    @Override
    public int getItemCount() {
        return listEndereco.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        private TextView txt_um, txt_dois, txt_id;

        public MyViewHolder(View itemView) {
            super(itemView);

            iniciarcomponentes(itemView);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(itemView.getContext(), MapsActivity2.class);
                    intent.putExtra("endereco",txt_um.getText().toString()+" - "+txt_dois.getText().toString());
                    itemView.getContext().startActivity(intent);
                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                    builder.setTitle("Exclusão");
                    builder.setMessage("Deseja excluir meso esse endereço?\n "+txt_um.getText().toString()+" - "+txt_dois.getText().toString());
                    builder.setCancelable(false);
                    builder.setNegativeButton("Não", null);
                    builder.setPositiveButton("Excluir", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            BancoControlador db = new BancoControlador(itemView.getContext());

                            db.deletarRegistro(Integer.parseInt(txt_id.getText().toString()));

                            Toast.makeText(itemView.getContext(), "endereço removida com sucesso!", Toast.LENGTH_SHORT).show();

                            listEndereco.remove(getAdapterPosition());
                            notifyItemRemoved(getAdapterPosition());

                        }
                    });
                    builder.show();

                    return false;
                }
            });

        }

        private void iniciarcomponentes(View itemView) {
            txt_um = itemView.findViewById(R.id.txt_um);
            txt_dois = itemView.findViewById(R.id.txt_dois);
            txt_id = itemView.findViewById(R.id.txt_id);

        }
    }
}
