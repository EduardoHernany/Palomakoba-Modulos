package com.example.myprojetofinal.Layouts;

import android.content.ContentValues;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;

import com.example.myprojetofinal.CEP.CEP;
import com.example.myprojetofinal.CEP.CEPService;
import com.example.myprojetofinal.R;
import com.example.myprojetofinal.bd.BancoControlador;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class AddDialogFragment extends DialogFragment {


    public AddDialogFragment() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_create, container);
        //return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onStart() {
        super.onStart();
        getDialog().getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    @Override
    public void show(@NonNull FragmentManager manager, @Nullable String tag) {
        super.show(manager, tag);
    }

    private Button ok, salvar,buscar;
    private EditText txt_cep;
    private TextView dados;
    private Retrofit retrofit;

    private BancoControlador bd ;
    
    private CEP cep;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        inciarcomponentes(view);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });

        String urlCep = "https://viacep.com.br/ws/";
        retrofit = new Retrofit.Builder()
                .baseUrl(urlCep)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        salvar.setAlpha(0);

        buscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recuperarCep();
                Toast.makeText(getContext(), "Buscando cep...", Toast.LENGTH_SHORT).show();
                Thread thread = new Thread();
                try {
                    thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bd = new BancoControlador(getContext());

                ContentValues cv = new ContentValues();

                cv.put("cep", cep.getCep());
                cv.put("logradouro", cep.getLogradouro());
                cv.put("complemento", cep.getComplemento());
                cv.put("bairro", cep.getBairro());
                cv.put("localidade", cep.getLocalidade());
                cv.put("uf", cep.getUf());

                long res = bd.inserir(cv);
                if(res > 0){
                    Toast.makeText(getContext(), "Salvo com sucesso!", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getContext(), "Erro ao salvar!", Toast.LENGTH_SHORT).show();
                }

                Thread thread = new Thread();
                try {
                    thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                dismiss();

            }
        });


    }


    private void recuperarCep(){
        CEPService cepService = retrofit.create(CEPService.class);
        //Call<CEP> call = cepService.recuperarCEP("76801058");
        Call<CEP> call = cepService.recuperarCEP(txt_cep.getText().toString());
        call.enqueue(new Callback<CEP>() {
            @Override
            public void onResponse(Call<CEP> call, Response<CEP> response) {
                if(response.isSuccessful()){
                    cep = response.body();
                    dados.setText(cep.getLogradouro()+"/"+cep.getBairro());
                    salvar.setAlpha(1);
                }else{
                    dados.setText("Cep invalido ");
                    salvar.setAlpha(0);
                }
            }

            @Override
            public void onFailure(Call<CEP> call, Throwable t) {

            }
        });
    }


    public void inciarcomponentes(View view){
        ok= view.findViewById(R.id.ok);
        buscar =view.findViewById(R.id.btn_buscar);
        salvar = view.findViewById(R.id.btn_salvar);
        dados= view.findViewById(R.id.txt_dados);
        txt_cep = view.findViewById(R.id.txt_cep);


    }

}
