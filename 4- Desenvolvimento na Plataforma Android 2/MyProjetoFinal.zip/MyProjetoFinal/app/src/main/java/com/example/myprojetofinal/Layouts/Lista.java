package com.example.myprojetofinal.Layouts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.myprojetofinal.R;
import com.example.myprojetofinal.adapter.Adapter;
import com.example.myprojetofinal.bd.BancoControlador;

import java.util.ArrayList;
import java.util.List;

public class Lista extends AppCompatActivity {
    private BancoControlador bd;
    private Button voltar;
    private RecyclerView recyclerView;
    private List<ContentValues> listEndereco = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);

        iniciarcomponentes();

        bd = new BancoControlador(getApplicationContext());

        //listEndereco = ;

        //Adapter adapter = new Adapter(listEndereco);
        Adapter adapter = new Adapter(bd.pesquiarPorTodos());

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);

        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void iniciarcomponentes() {
        voltar = findViewById(R.id.volar_lista);
        recyclerView= findViewById(R.id.recycler_lista);
    }
}