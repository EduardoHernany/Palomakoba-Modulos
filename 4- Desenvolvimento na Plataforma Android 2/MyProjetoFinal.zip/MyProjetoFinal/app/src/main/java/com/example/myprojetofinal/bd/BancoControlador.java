package com.example.myprojetofinal.bd;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class BancoControlador extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "MYMAPSDB";
    private static final int DATABASE_VERSION = 1;
    private final String CREATE_TABLE_CEP =
            "CREATE TABLE ceptable ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "cep TEXT, logradouro TEXT, complemento TEXT, "
                    + "bairro TEXT, localidade TEXT, uf TEXT);";

    public BancoControlador(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_CEP);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS ceptable");
        onCreate(sqLiteDatabase);
    }

    public long inserir(ContentValues cv){
        SQLiteDatabase db = this.getWritableDatabase();
        long id = db.insert("ceptable", null, cv);
        return id;
    }

    public List<ContentValues> pesquiarPorTodos(){
        String sql = "SELECT * FROM ceptable ORDER BY id";
        String where[] = null;
        return pesquisar(sql, where);
    }

    @SuppressLint("Range")
    private List<ContentValues> pesquisar(String sql, String where[]){
        List<ContentValues> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(sql, where);

        if (c.moveToFirst()){
            do{
                ContentValues cv = new ContentValues();
                cv.put("id", c.getInt(c.getColumnIndex("id")));

                cv.put("cep", c.getString(c.getColumnIndex("cep")));

                cv.put("logradouro", c.getString(c.getColumnIndex("logradouro")));

                cv.put("complemento", c.getString(c.getColumnIndex("complemento")));

                cv.put("bairro", c.getString(c.getColumnIndex("bairro")));

                cv.put("localidade", c.getString(c.getColumnIndex("localidade")));

                cv.put("uf", c.getString(c.getColumnIndex("uf")));

                lista.add(cv);
            }while(c.moveToNext());
        }

        return lista;
    }

    public void deletarRegistro(int id){
        String where = "id=" + id;
        SQLiteDatabase db = this.getReadableDatabase();
        db.delete("ceptable", where, null);
        db.close();
    }
}
